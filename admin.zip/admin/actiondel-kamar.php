<?php 

include "../config.php";

$id = $_GET['id'];
$del = mysqli_query($koneksi,"DELETE FROM tb_kamar where id_kamar='$id' ");


// echo $insert;
if ($del) {
    header('location:kamar.php');
}else{
    header('location:form-kamar.php');
}

?>