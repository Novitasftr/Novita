<?php
// mengaktifkan session php
session_start();

// menghubungkan dengan koneksi database
include '../config.php';

// menangkap data yang dikirim dari form
$username = $_POST['username'];
$kata_sandi = $_POST['kata_sandi'];

// menyeleksi data tamu dengan email dan password yang sesuai
$data = mysqli_query($koneksi,"SELECT * from tb_admin where username='$username' AND password='$kata_sandi'");

// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);


if($cek > 0){
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "login";
    header("location:index.php");
}else{
	header("location:login-admin.php");
}
?>