<?php 

include "../config.php";

$tipe = $_POST['tipe_kamar'];
$jml = $_POST['jml_bed'];
$harga = $_POST['harga_kamar'];
$action = $_POST['action'];
if ($action == "tambah") {
    $insert = mysqli_query($koneksi,"INSERT INTO tb_kamar (nama_kamar,jml_bed,harga_kamar) VALUES ('$tipe', $jml,$harga)");
}else if($action == "edit"){
    $id = $_POST['id'];
    $insert = mysqli_query($koneksi,"UPDATE tb_kamar SET nama_kamar='$tipe', jml_bed='$jml', harga_kamar='$harga' where id_kamar='$id'");
}

// echo $insert;
if ($insert) {
    header('location:kamar.php');
}else{
    header('location:form-kamar.php');
}

?>