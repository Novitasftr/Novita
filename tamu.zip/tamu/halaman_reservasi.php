<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Checkout example · Bootstrap v5.1</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/checkout/">

    

    <!-- Bootstrap core CSS -->
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="../assets/css/form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">
     <!-- cek apakah sudah login -->
	<?php 
	session_start();
    
	if($_SESSION['status']!="login"){
		header("location:index.php?pesan=belum_login");
 
	}
?>
<?php
  include "../config.php";
 
$email = $_SESSION['email'];
$id_kamar= $_GET['id_kamar'];
// echo "$id_kamar"; die();
//mengambil data kamar
$data_kamar = mysqli_query($koneksi,"select * from tbl_tipe_kamar where id_kamar='$id_kamar'");
	$kamar = mysqli_fetch_array($data_kamar);
  // $k=$kamar['nm_tipe_kamar'];
  // echo "$k";

$data = mysqli_query($koneksi,"select * from tbl_tamu where email='$email'");
	$row = mysqli_fetch_array($data);

  $query = mysqli_query($koneksi,"select * from tbl_reservasi JOIN tbl_tamu ON tbl_reservasi.kd_tamu=tbl_tamu.kd_tamu
                     JOIN tbl_tipe_kamar ON tbl_reservasi.id_kamar=tbl_tipe_kamar.id_kamar where email='$email'");
	$reservasi = mysqli_fetch_array($query);

	// mengambil data tamu dengan kode paling besar
	$query = mysqli_query($koneksi, "SELECT max(kd_reservasi) as kd_reservasi FROM tbl_reservasi");
	$data = mysqli_fetch_array($query);
	$kd_reservasi = $data['kd_reservasi'];
 
	$urutan = (int) substr($kd_reservasi, 3, 3);
 
	// bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
	$urutan++;
 
	// membentuk kode barang baru
	// perintah sprintf("%03s", $urutan); berguna untuk membuat string menjadi 3 karakter
	// misalnya perintah sprintf("%03s", 15); maka akan menghasilkan '015'
	// angka yang diambil tadi digabungkan dengan kode huruf yang kita inginkan, misalnya BRG 
	$huruf = "RSV";
	$kd_reservasi = $huruf . sprintf("%03s", $urutan);
	?>
    <h1>Welcome <?php echo $_SESSION['email']; ?></h1>
  <?php if ($reservasi['id_kamar']==NULL && $reservasi['status_reservasi']==NULL) {
  ?>
<div class="container">
  <main>


  
    <div class="py-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/img/logo_login.jpg" alt="" width="72" height="57">
      <h2>Checkout form</h2>
      <p class="lead">Below is an example form built entirely with Bootstrap’s form controls. Each required form group has a validation state that can be triggered by attempting to submit the form without completing it.</p>
    </div>

    <div class="row g-5">
      <div class="col-md-5 col-lg-4 order-md-last">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-primary">Your cart</span>
          <span class="badge bg-primary rounded-pill">3</span>
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Product name</h6>
              <small class="text-muted">Brief description</small>
            </div>
            <span class="text-muted">$12</span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Second product</h6>
              <small class="text-muted">Brief description</small>
            </div>
            <span class="text-muted">$8</span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Third item</h6>
              <small class="text-muted">Brief description</small>
            </div>
            <span class="text-muted">$5</span>
          </li>
          <li class="list-group-item d-flex justify-content-between bg-light">
            <div class="text-success">
              <h6 class="my-0">Promo code</h6>
              <small>EXAMPLECODE</small>
            </div>
            <span class="text-success">−$5</span>
          </li>
          <li class="list-group-item d-flex justify-content-between">
            <span>Total (USD)</span>
            <strong>$20</strong>
          </li>
        </ul>

        <form class="card p-2">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Promo code">
            <button type="submit" class="btn btn-secondary">Redeem</button>
          </div>
        </form>
      </div>
      <div class="col-md-7 col-lg-8">
        <h4 class="mb-3">Billing address</h4>
        <form method="POST" action="aksi_rsvp.php" class="needs-validation" novalidate>
          <div class="row g-3">
            <div class="col-sm-6">
              <label for="firstName" class="form-label">Nama Lengkap</label>
              <input type="text" class="form-control" id="firstName" placeholder="" value="<?php echo $row['nama_tamu'];?>" name="nama_tamu" readonly>
              <input type="hidden" class="form-control"  name="kd_reservasi" value="<?php echo $kd_reservasi;?>">
              <input type="hidden" class="form-control"  name="kd_tamu" value="<?php echo $row['kd_tamu'];?>">
              <input type="hidden" class="form-control"  name="tgl_dipesan" value="<?php echo date("Y-m-d"); ?>">
              <input type="hidden" class="form-control"  name="id_kamar" value="<?php echo $kamar['id_kamar'];?>">
              <div class="invalid-feedback">
                Valid first name is required.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="email" class="form-label">Jenis Kamar </label>
              <input type="text" class="form-control" placeholder="tipe kamar" name="nm_tipe_kamar" value="<?php echo $kamar['nm_tipe_kamar'];?>" readonly>
              <!-- <div class="invalid-feedback">
                Please enter a valid email address for shipping updates.
              </div> -->
            </div>
           
            <div class="col-12">
              <label for="address" class="form-label">Address</label>
              <input type="text" class="form-control" id="address" value="<?php echo $row['alamat']?>" readonly>
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="lastName" class="form-label">Jumlah Kamar yang Dipesan</label>
              <input type="number" class="form-control" id="lastName" placeholder="jumlah kamar" name="jml_kamar" min=1 max="<?php echo $kamar['jml_kamar'];?>"required>
              <div class="invalid-feedback">
                Isi jumlah kamar yang ingin dipesan.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="lastName" class="form-label">Jumlah Orang</label>
              <input type="number" name="jml_orang" class="form-control" id="lastName" placeholder="jumlah orang" name="jml_orang" min=1 max="<?php echo $kamar['batas_orang'];?>" required>
              <div class="invalid-feedback">
                Isi jumlah orang yang akan menginap.
              </div>
            </div>
      
            <div class="col-md-6">
              <label for="country" class="form-label">Check In</label>
              <input type="date" class="form-control" id="country" name="tgl_cek_in" min="<?php echo date("Y-m-d"); ?>" required>
              <div class="invalid-feedback">
                Please select a valid country.
              </div>
            </div>

            <div class="col-md-6">
              <label for="country" class="form-label">Check Out</label>
              <input type="date" class="form-control" id="country" name="tgl_cek_out" min="<?php echo date("Y-m-d"); ?>" required>
              <div class="invalid-feedback">
                Please select a valid country.
              </div>
            </div>

            <div class="col-6">
              <label for="username" class="form-label">Lama Menginap</label>
              <div class="input-group has-validation">
              <input type="hidden" class="form-control" id="harga_kamar" name="harga_kamar" onkeyup="total()" value="<?php echo $kamar['harga_kamar'];?>" required>
                <input type="text" class="form-control" id="jml_hari" name="jml_hari" onkeyup="total()" min=1 placeholder="Lama menginap" required>
                <span class="input-group-text">malam</span>
              <div class="invalid-feedback">
                  Isi lama menginap.
                </div>
              </div>
            </div>


            <div class="col-md-6">
              <label for="zip" class="form-label">Total Bayar</label>
              <input type="text" class="form-control"  id="total_bayar" name="total_bayar" readonly>
              <!-- <div class="invalid-feedback">
                Zip code required.
              </div> -->
            </div>
          </div>

          <hr class="my-4">

          <button class="w-100 btn btn-primary btn-lg" type="submit">Pesan Sekarang</button>
        </form>
      </div>
    </div>
  <?php } 

  elseif ($reservasi['status_reservasi']==0) {
    echo "<h2> Anda sudah memesan tipe kamar ini, silahkan melakukan pembayaran pemesanan kamar hotel anda.</h2>";
  } elseif ($reservasi['status_reservasi']==1) {
    echo "<h2> silahkan melakukan check in kamar hotel anda, sesuai jadwal yang telah ditentukan.</h2>";
  } elseif ($reservasi['status_reservasi']==2) {
    echo "<h2> silahkan melakukan check out kamar hotel anda, sesuai jadwal yang telah ditentukan.</h2>";
  } 
   
  ?>
  </main>

  <footer class="my-5 pt-5 text-muted text-center text-small">
    <p class="mb-1">&copy; 2017–2021 Company Name</p>
    <ul class="list-inline">
      <li class="list-inline-item"><a href="#">Privacy</a></li>
      <li class="list-inline-item"><a href="#">Terms</a></li>
      <li class="list-inline-item"><a href="#">Support</a></li>
    </ul>
  </footer>
</div>


    <script src="../assets/js/bootstrap.bundle.min.js"></script>

      <script src="../assets/js/form-validation.js"></script>
  </body>
  <script>
function total() {
      var txtFirstNumberValue = document.getElementById('harga_kamar').value;
      var txtSecondNumberValue = document.getElementById('jml_hari').value;
      var result = parseInt(txtFirstNumberValue) * parseInt(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('total_bayar').value = result;
      }
}
</script>
</html>
