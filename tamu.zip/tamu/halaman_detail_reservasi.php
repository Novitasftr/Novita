<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>DETAIL RESERVASI</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/checkout/">

    

    <!-- Bootstrap core CSS -->
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="../assets/css/form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">
       <!-- cek apakah sudah login -->
	<?php 
	session_start();
    
	if($_SESSION['status']!="login"){
		header("location:index.php?pesan=belum_login");
 
	}
?>
  <?php
  include "../config.php";
 
$email = $_SESSION['email'];
$kd_reservasi = $_GET['kd_reservasi'];
$data = mysqli_query($koneksi,"select * from tbl_reservasi JOIN tbl_tamu ON tbl_reservasi.kd_tamu=tbl_tamu.kd_tamu
                     JOIN tbl_tipe_kamar ON tbl_reservasi.id_kamar=tbl_tipe_kamar.id_kamar where kd_reservasi='$kd_reservasi'");
	$row = mysqli_fetch_array($data);
// echo "$kd_reservasi"; die();
?>
<div class="container">
  <main>
    <div class="py-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/img/logo_login.jpg" alt="" width="72" height="57">
      <h2>DETAIL RESERVASI ANDA</h2>
      <p class="lead"></p>
    </div>

    <div class="row g-5">
      <div class="col-md-5 col-lg-4 order-md-last">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-primary">Lakukan pembayaran via transfer bank</span>
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">BCA</h6>
              <small class="text-muted">0202022921093404</small>
            </div>
           
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Mandiri</h6>
              <small class="text-muted">839483974389743890</small>
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Batas Waktu Pembayaran</h6>
              <small class="text-muted">839483974389743890</small>
            </div>
            
          </li>
        </ul>

      
      </div>
      <div class="col-md-7 col-lg-8">
       
      <h4 class="mb-3">Nomor Reservasi   : #<?php echo $row['kd_reservasi'];?></h4>
      <h5 class="mb-3">Tanggal Reservasi : <?php echo $row['tgl_dipesan'];?></h5>
          <hr class="my-4">
              <label class="form-check-label" for="credit">Nama Pemesan    : <?php echo $row['nama_tamu'];?></label>
              <label class="form-check-label" for="credit">Email           : <?php echo $row['email'];?></label>
              <label class="form-check-label" for="credit">Waktu Check In:  <?php echo $row['tgl_check_in'];?> / Pukul: 13.00 WIB</label>
              <label class="form-check-label" for="credit">Waktu Check Out: <?php echo $row['tgl_check_out'];?> / Pukul: 12.00 WIB</label>
              <label class="form-check-label" for="credit">Terhitung <?php echo $row['jml_hari'];?> malam</label>
              <label class="form-check-label" for="credit">Tipe Kamar  : <?php echo $row['nm_tipe_kamar'];?></label>
              <label class="form-check-label" for="credit">Fasilitas Kamar: <?php echo $row['fasilitas_kamar'];?></label>
              <label class="form-check-label" for="credit">Jumlah Kamar: <?php echo $row['jml_kamar_dipesan'];?></label>
              <label class="form-check-label" for="credit">Jumlah Orang: <?php echo $row['jml_orang'];?></label>
              <label class="form-check-label" for="credit">Total Bayar: <?php echo $row['total_bayar'];?></label>
          <hr class="my-4">

          <button class="w-100 btn btn-primary btn-lg" type="submit"><a style="color: white;" href="halaman_pembayaran.php?kd=<?=$row['kd_reservasi'];?>">Lanjutkan ke Pembayaran</a></button>
        </form>
      </div>
    </div>
  </main>

  <footer class="my-5 pt-5 text-muted text-center text-small">
    <p class="mb-1">&copy; 2017–2021 Company Name</p>
    <ul class="list-inline">
      <li class="list-inline-item"><a href="#">Privacy</a></li>
      <li class="list-inline-item"><a href="#">Terms</a></li>
      <li class="list-inline-item"><a href="#">Support</a></li>
    </ul>
  </footer>
</div>


    <script src="../assets/js/bootstrap.bundle.min.js"></script>

      <script src="../assets/js/form-validation.js"></script>
  </body>
</html>
